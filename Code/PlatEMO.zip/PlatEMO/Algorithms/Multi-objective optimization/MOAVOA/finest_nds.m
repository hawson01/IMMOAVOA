function finestSet = finest_nds(ndSet, Cost)%（挑选非支配解作为全局最优解）
%% 参数初始化
nP = size(Cost, 1); % 种群大小
ndLength = size(ndSet, 2); % 非支配集大小
ndCost = Cost(ndSet, :); % 非支配集的目标值
crowdingDis = crowding_distance(ndCost); % 非支配集的聚集距离
%% 用来排除一些特殊点（单个目标值差距很大导致的聚集距离大的点）
element = elementSort(ndCost);
comMetric = crowdingDis - element;
%% 确定挑选多少个非支配排序解作为全局最优解
%从非支配解集中找出最优的一些来作为更新的最优解，非支配解的占比来决定选择解的个数
%前期非支配解占比小，挑的越多，后期非支配解占比多，挑的少
%原因：每选一个非支配解来充当全局最优解时，就会将这个非支配解所支配的个体进行自更新，不同的非支配解支配的解是有重合的
%有些解会进行多次更新，对前期来说是好的，但是后期不合适，所以后期挑的解少
[~, sortedIndex] = sort(comMetric, "descend"); % 将非支配集按降序排序
% 高斯分布挑选比例（单调递减的函数，前期降的比较慢，后期降的比较快，凑出来的）
mu = 0;
sigma = nP/4;
selectPortion = exp(-(ndLength-mu)^2/(2*sigma^2)); % 挑选的比例
selectNum = ceil(ndLength*selectPortion); % 挑选前多少个非支配解
%% 挑选非支配解
%用聚集距离来挑选非支配解，如果挑选解的个数较小，排除聚集距离最大的两个，从后面开始挑，因为会一直挑到边界点
%如果挑选解个数足够大，直接就挑前三个。聚集距离越大越容易被挑
if ndLength-2<selectNum
    finestSet = ndSet(sortedIndex(1:selectNum)); % 存储最优非支配解的索引
else
    % 排除掉聚集距离一定最大的边界
    finestSet = ndSet(sortedIndex(3:selectNum+2)); % 存储最优非支配解的索引
end
end

