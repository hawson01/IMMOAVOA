function [F, pRank] = non_domination_sort(Cost)
%简单非支配排序和计算拥挤度
nP = size(Cost, 1); %种群大小
%dim = size(X, 2); %个体维数

%简单支配关系法，定义个体适应度为fitness(i) = 1+ni
%其中ni为支配个体i的个体数
pRank = ones(nP, 1);%储存个体等级信息
F = zeros(nP, nP); % 分类集合
dominant = zeros(nP, nP); % 支配表,(i,j)==1:个体i支配j
for i=1:nP
    %%%计算出个体i的被支配个数和个体i的支配集
    for j=i+1:nP
        sub_f = Cost(i, :) - Cost(j, :); %目标值作差
        sub_f_pos = size(find(sub_f > 0), 2); %差值中正数的个数
        sub_f_neg = size(find(sub_f < 0), 2); %差值中负数的个数
        if (sub_f_neg > 0 && sub_f_pos == 0)
            % i支配个体j,将j加入i的支配集
            dominant(i, j) = 1;
        elseif (sub_f_pos > 0 && sub_f_neg ==0)
            % i被个体j支配,i的被支配个体数加一
            dominant(j, i) = 1;
        end    
    end
end

%%%将种群中非支配个体放入集合F(1)中
dominated = sum(dominant); % 每个个体被支配的个体数
F(1, dominated == 0) = 1; % 非支配个体索引集
pRank(dominated == 0) = 1; % 更新帕累托等级

%%%将所有个体填充进F
dominated(logical(F(1, :))) = Inf; % 让非支配个体不可选出
it = 1; % 类标
while(size(find(dominated ~= Inf), 2) ~= 0)
    % 当种群中还有个体未被分配时
    thisDominant = repmat(F(it, :).', 1, nP) .* dominant; % 当前类所支配的个体
    thisDominated = sum(thisDominant); % 将此类所支配个体数目相加
    dominated = dominated - thisDominated; % 减去之后若<0则被当前类所支配
    nextF = dominated <= 0; % 被当前类所支配的个体索引
    F(it+1, nextF) = 1; % 将被当前类所支配的个体加入下一类
    pRank(nextF) = it+1; %更新帕累托等级
    dominated(nextF) = Inf; % 让下一类个体不可再被选出
    it = it+1;
end
F(all(F == 0, 2), :) = []; % 删除全0行, 即空类
end

