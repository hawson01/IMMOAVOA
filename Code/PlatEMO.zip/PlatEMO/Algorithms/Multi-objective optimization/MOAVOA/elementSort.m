function element = elementSort(Cost)
% 个体目标函数值中fum-1个函数值的组合的最小值，用以剔除单个目标值差距很大导致的聚集距离大（离群点）
fNum = size(Cost, 2);%目标函数个数
nP = size(Cost, 1);%种群大小
element = zeros(nP, 1);%用于存储每个个体的离群程度
for i=1:nP
    nums = nchoosek(Cost(i, :), fNum-1);%排列组合函数，每次从目标函数中取fNum-1个值进行组合的结果，行数为组合可能的数量
    element(i, 1) = min(sum(nums, 2));%取组合最小值
end
element = (element - min(element)) / (max(element) - min(element));
end

