function domainSetIndex = select(Findex, F, Cost)
% 找出F(1)中Findex号个体所支配的个体索引
ndSet = find(F(1, :) == 1); % 非支配集
if(Findex > size(ndSet))
    0;
end
ndObject = ndSet(Findex); % 当前非支配个体
nP = size(Cost, 1); % 种群大小
domainSetIndex = []; % 当前非支配个体所支配的个体以及其本身
for i=1:nP
    sub_f = Cost(ndObject, :) - Cost(i, :); %目标值作差
    sub_f_pos = size(find(sub_f > 0), 2); %差值中正数的个数
    % 如果当前非支配个体每个值都<=个体i的值,则其支配i或者与i相等
    if (sub_f_pos == 0)
        domainSetIndex = [domainSetIndex, i];
    end
end
end

