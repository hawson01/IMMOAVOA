function newPop = grid_select(pop, newNp)
%为了选出分布性高的点
% 计算初始信息
Cost = pop.objs;
% 网格法对非支配解进行挑选
nP = size(Cost, 1);
f_num = size(Cost, 2);
div = floor(nP ^ (1/f_num) *exp(0.4)) + 1;%代表一个方向化多少格，调参调出来的
pos = zeros(nP, f_num); % 个体所在网格编号
bottomBrinks = zeros(nP, f_num); % 个体所在网格的下边界
topBrinks = zeros(nP, f_num); % 个体所在网格的上边界
newPop = pop(1:newNp);%初始化新种群
minIndex = zeros(f_num, 1);
% 构建网格
grid = zeros(div+1, f_num);
for i=1:f_num
    f = Cost(:, i);
    [fmin, minIndex(i, 1)] = min(f);
    fmax = max(f);
    gap = (fmax-fmin) / div;
    grid(:, i) = linspace(fmin - gap/2, fmax+gap/2, div+1);
end
% 找出所有个体所在的网格编号
for i=1:nP
    sub_f = repmat(Cost(i, :), div, 1) - grid(1:div, :);
    for j=1:f_num
        % 网格编号
        pos(i, j) = find(sub_f(:, j)>=0, 1, "last");
        % 上下界
        bottomBrinks(i, j) = grid(pos(i, j), j);
        topBrinks(i, j) = grid(pos(i, j)+1, j);
    end
end
% 开始挑选
remainNum = newNp; % 剩余挑选数目
ind = 1; % 当前补位下标
while remainNum ~= 0
    % 临时存储数据
    tempPos = pos;
    tempBottom = bottomBrinks;
    tempTop = topBrinks;
    % 计算网格信息
    [uniPos, ~, labels] = unique(pos, 'rows');
    analysis = tabulate(labels);    
    gridNum = size(analysis, 1); % 非空网格数目
    if gridNum <= remainNum
        % 每个格子里面挑选一个
        select = analysis(:, 1);
    else
        % 随机所有网格里面挑选出相应个数的网格（网格数大于所需个体数）
        select = randperm(size(analysis, 1), remainNum);
    end
    % 在网格中挑选中心偏差最小的个体
    selectNum = length(select);
    for i=1:selectNum
        currentBlock = uniPos(select(i), :);
        indexIn = find(sum(currentBlock == pos, 2) == f_num);
        costsIn = Cost(indexIn, :);
        popIn = pop(indexIn);
        bottom = bottomBrinks(indexIn(1), :);
        top = topBrinks(indexIn(1), :);
        % 计算中心偏差
        costsInNum = size(costsIn, 1);
        gridLen = top - bottom;
        subDis = abs((costsIn - repmat(bottom, costsInNum, 1)) - (repmat(top, costsInNum, 1) - costsIn));
        centreDiv = sum(subDis ./ repmat(gridLen, costsInNum, 1), 2);
        % 将中心偏差最小的加入新种群
        [~, divIndex] = sort(centreDiv);
        newPop(ind) = popIn(divIndex(1));
        % 挑选之后的更新
        ind = ind + 1;
        remainNum = remainNum - 1;
        % 更新网格,以选出的个体为中心再划分
        newCost = newPop(ind-1).obj;
        for j=1:f_num
            % 将高于原来网格编号提升以空出空位
            upIndex = tempPos(:, j) > currentBlock(j);
            tempPos(upIndex, j) = tempPos(upIndex, j) + 1;
            % 将网格内的个体位置更新
            highIndex = (costsIn(:, j) - newCost(j)) >= 0;
            lowIndex = ~highIndex;
            tempPos(indexIn(highIndex), j) = tempPos(indexIn(highIndex), j) + 1;
            % 更新高位格内个体的下界
            tempBottom(indexIn(highIndex), j) = newCost(j);
            % 更新低位格内个体的上界
            tempTop(indexIn(lowIndex), j) = newCost(j);
        end
        % 排除已经选择的个体
        Cost(indexIn(divIndex(1)), :) = [];
        pos(indexIn(divIndex(1)), :) = [];
        topBrinks(indexIn(divIndex(1)), :) = [];
        bottomBrinks(indexIn(divIndex(1)), :) = [];
        pop(indexIn(divIndex(1))) = [];
        % 临时存储数据也变化
        tempPos(indexIn(divIndex(1)), :) = [];
        tempBottom(indexIn(divIndex(1)), :) = [];
        tempTop(indexIn(divIndex(1)), :) = [];
    end
    % 更新信息
    pos = tempPos;
    bottomBrinks = tempBottom;
    topBrinks = tempTop;
end

end

