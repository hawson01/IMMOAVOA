function newPop = eliminate(pop, nP)
% 配置
Cost = pop.objs;
%% 排除异常点
f_num = size(Cost, 2);
for i=1:f_num
    currentCost = Cost(:, i);
    %计算上界
    meanCost = mean(currentCost);
    level = log10(meanCost);
    level = ceil(level);
    level(level < 0) = 0;
    ub = 2 * (10 ^ level);
    %计算异常点
    oddIndex = find((currentCost > ub));
    if size(Cost, 1) - length(oddIndex) < nP
        % 若不能全部去除，则挑选偏离最远的个体去除
        eliNum = size(Cost, 1) - nP;
        oddCost = currentCost(oddIndex);
        [~, eliIndex] = sort(oddCost, "descend");
        eliIndex = eliIndex(1:eliNum);
        pop(oddIndex(eliIndex)) = [];
    else
        % 若可以全部去除，则全部去除
        pop(oddIndex) = [];
    end
    Cost = pop.objs;
    if size(Cost, 1) == nP
        break
    end
end
%% 非支配排序（与NSGA-Ⅱ相同，加了一个网格法）
[F, ~] = ndsort(Cost, pop.cons, nP);
% 从X中挑选nP个个体作为种群
classIndex = 1; % 当前检索种群
remainNum = nP; % 种群缺少数
newIndex = 1; % 新种群的当前下标
while remainNum ~= 0
    class = find(F(classIndex, :) == 1); % 当前类的索引
    classLen = length(class); % 当前类大小
    if remainNum - classLen >= 0
        % 若当前类可全部放入新种群
        newPop(newIndex:newIndex + classLen - 1) = pop(class);
        newIndex = newIndex + classLen;
        remainNum = remainNum - classLen;
    else
        % 若当前类不可全部放入新种群
        if classIndex==1
            %若非支配解无法全部放入,则使用网格法限制（原种群全为非支配解时，更新出来的也基本上都是非支配解时）
            classPop = pop(class);
            newPop = grid_select(classPop, remainNum);
        else
            % 挑选聚集距离高的个体加入
            classCost = Cost(class, :);
            classPop = pop(class);
            crowdingDis = crowding_distance(classCost); % 当前类个体的聚集距离
            [~, sortedIndex] = sort(crowdingDis, 'descend'); % 对聚集距离排序
            sortedPop = classPop(sortedIndex);
            newPop(newIndex: newIndex + remainNum - 1) = sortedPop(1:remainNum);
        end
        remainNum = 0;
    end
    classIndex = classIndex + 1;
end
end

