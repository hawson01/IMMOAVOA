function [F,MaxFNo] = ndsort(varargin)
    PopObj = varargin{1};
    [N,M]  = size(PopObj);
    PopCon = varargin{2};
    nSort = varargin{3};
    if ~isempty(PopCon)
        Infeasible           = any(PopCon>0,2);
        PopObj(Infeasible,:) = repmat(max(PopObj,[],1),sum(Infeasible),1) + repmat(sum(max(0,PopCon(Infeasible,:)),2),1,M);
    end
    if M < 3 || N < 500
        % 简单非支配排序
        [F,MaxFNo] = non_domination_sort(PopObj);
    else
        % 非支配树排序
        [F,MaxFNo] = T_ENS(PopObj,nSort);
    end

end

function [F,MaxFNo] = T_ENS(PopObj,nSort)
    [PopObj,~,Loc] = unique(PopObj,'rows'); % [不重复目标值, ~, 还原序列]
    Table     = hist(Loc,1:max(Loc)); % 每个不重复值有多少个个体
	[N,M]     = size(PopObj);
    FrontNo   = inf(1,N);
    MaxFNo    = 0;
    Forest    = zeros(1,N); % 
    Children  = zeros(N,M-1); % 孩子节点
    LeftChild = zeros(1,N) + M; % 左孩子节点
    Father    = zeros(1,N); % 父节点
    Brother   = zeros(1,N) + M; % 兄弟节点
    [~,ORank] = sort(PopObj(:,2:M),2,'descend'); % 后M-1个目标间降序排序
    ORank     = ORank + 1; % 后M-1个目标间降序序号加一，即第一个目标最高
    while sum(Table(FrontNo<inf)) < min(nSort,length(Loc))
        MaxFNo = MaxFNo + 1; % 当前循环的支配级别
        root   = find(FrontNo==inf,1); % 将第一个支配等级为inf的个体设为根节点(自底向上)
        Forest(MaxFNo) = root; % 森林的根节点索引与支配级别相对应 
        FrontNo(root)  = MaxFNo; % 将当前根节点的支配等级设为循环的支配等级
        for p = 1 : N % 对每个个体进行判定
            if FrontNo(p) == inf % 若当前个体未进行任何操作
                Pruning = zeros(1,N); % 修剪数组
                q = Forest(MaxFNo); % q存储当前循环根节点
                while true
                    m = 1; % 第m个目标函数
                    while m < M && PopObj(p,ORank(q,m)) >= PopObj(q,ORank(q,m))
                        % ORank(q,m)为根节点第m+1个目标的降序序号
                        % 不会比较p与q的第一个目标函数
                        m = m + 1;
                    end
                    if m == M 
                        % 除第一个目标函数外,p的每个目标值都>=根节点(被根节点支配)
                        break;
                    else
                        % 除第一个目标函数外,p存在至少一个目标值<根节点(支配根节点或不相关)
                        Pruning(q) = m; % 存储根节点大于p的目标值的排序索引
                        if LeftChild(q) <= Pruning(q)
                            % 如果根节点左孩子<=排序索引
                            q = Children(q,LeftChild(q));
                        else
                            while Father(q) && Brother(q) > Pruning(Father(q))
                                q = Father(q);
                            end
                            if Father(q)
                                q = Children(Father(q),Brother(q));
                            else
                                break;
                            end
                        end
                    end
                end
                if m < M
                    FrontNo(p) = MaxFNo;
                    q = Forest(MaxFNo);
                    while Children(q,Pruning(q))
                        q = Children(q,Pruning(q));
                    end
                    Children(q,Pruning(q)) = p;
                    Father(p) = q;
                    if LeftChild(q) > Pruning(q)
                        Brother(p)   = LeftChild(q);
                        LeftChild(q) = Pruning(q);
                    else
                        bro = Children(q,LeftChild(q));
                        while Brother(bro) < Pruning(q)
                            bro = Children(q,Brother(bro));
                        end
                        Brother(p)   = Brother(bro);
                        Brother(bro) = Pruning(q);
                    end
                end
            end
        end
    end
    FrontNo = FrontNo(:,Loc);
    F = zeros(MaxFNo, nSort);
    for i=1:MaxFNo
        classIndex = FrontNo == i;
        F(i, classIndex) = 1;
    end
end