function crowdingDis = crowding_distance(Cost)
f_num = size(Cost, 2); % 目标函数数目
nP = size(Cost, 1); % 种群大小
crowdingDis = zeros(nP, f_num); % 所有个体的聚集距离
for i = 1:f_num
  %根据目标函数值对该等级的个体进行排序
  [tempCost, sortIndex] = sort(Cost(:, i)); % 计算对一个目标值的排序索引
  tempDis = zeros(nP, 1); % 临时记录聚集距离
  fmin = tempCost(1, 1); % 记录当前目标函数的最小值
  fmax = tempCost(nP, 1); % 记录当前目标函数的最大值
  if (fmax - fmin == 0)
      % 若所有目标函数值都一样, 则所有个体的聚集距离都为Inf
      tempDis(:, 1) = Inf;
  else
      % 对排序的两个边界拥挤度设置为无穷
      tempDis(1, 1) = Inf;
      tempDis(nP, 1) = Inf;
      %计算所有个体的聚集距离
      for j = 2:nP-1
          pref = tempCost(j-1, 1); % 上一个目标函数值
          nextf = tempCost(j+1, 1); % 下一个目标函数值
          tempDis(j, 1) = (nextf-pref)/(fmax-fmin);
      end
  end
  crowdingDis(sortIndex, i) = tempDis;
end
crowdingDis = sum(crowdingDis, 2);
end

