function newPop = MOPOBLAVOA1G_OP(Population,p1,p2,p3,alpha,betha,gamma,iter,maxit)
%生成两个POBL，取平均作为比较值比较,解集质量提高选择开发阶段
%% 初始配置
    Problem = PROBLEM.Current();
    X = Population.decs; % 种群位置
    Cost = Population.objs; % 目标函数值（N*目标函数个数）
    lb = Problem.lower; % 上界
    ub = Problem.upper; % 下界
    dim = size(X, 2); % 个体维数
    nP = size(X, 1); %种群大小
    it = iter + 1;
    MaxIt = maxit;
%     it = Problem.FE;
%     MaxIt = Problem.maxFE;
    pram1 = 20; % 参数1
    pram2 = 21; % 参数2
    f=pram1.*exp(-(pram2.*(it/MaxIt))); % (Eq.17.6)
    SF=2.*(0.5-rand(1,nP)).*f;
%% 非支配排序挑选全局最优解
    originX = X; % 用于保存当前循环的初始种群
    originCost = Cost; % 用于保存当前循环的初始目标值
    % 取出当前种群的非支配集
    [F, ~] = ndsort(Cost, Population.cons, nP);
    ndSet = find(F(1, :) == 1);%非支配排序解的索引
    finestSet = finest_nds(ndSet, Cost); % 找出最优非支配解（挑选非支配排序解作为全局最优解，根据拥挤距离来挑选）
    % 用于储存当前迭代中所有个体信息
    totalPop = Population;
    %%%开始循环
    % 把非支配集里的每个个体当作最佳解进行更新
    %% 对挑选出来的支配解的支配域进行更新
    for nd=1:length(finestSet)
        % 在初始种群中进行更新
        Best_X = originX(finestSet(nd), :); % 当前非支配解
        Best_Cost = originCost(finestSet(nd), :); % 当前最优目标值
%         ndSet = find(F(1, :) == 1); % 非支配集
%         if(nd >size(ndSet))
%             0;
%         end
        domain_index = select(nd, F, originCost); % 支配域的索引
        if length(domain_index) < 4%当支配域过少，全部种群都为支配域，越到后期，支配域个体越来越少，
            %为了防止非支配解一直不更新
            domain = X;
            domain_Cost = Cost;
            cons = Population.cons;
        else
            domain = originX(domain_index, :); % 当前非支配解的支配域
            domain_Cost = originCost(domain_index, :); % 当前支配域的目标值
            cons = Population(domain_index).cons;
        end
        current_nP = size(domain, 1); % 当前支配域的大小
        Xavg = mean(domain);
        for i=1:current_nP
            % 选出出当前支配域的最优个体（当前最优解）
            if current_nP == size(X, 1)
                % 若支配域为全体，则从全体非支配解中挑选一个（后期，个体大多数都为非支配解，这个情况下没有个体更新，只能让支配域为全体）
                lBest = X(ndSet(floor(rand*length(ndSet)) + 1), :);
            else
                % 若支配域不为全体，则非支配解只有一个
                lBest = Best_X;
            end
           % 计算delta
            gama = rand.*(domain(i,:)-rand(1,dim).*(ub-lb)).*exp(-4*it/MaxIt);  
            Stp=rand(1,dim).*((Best_X-rand.*Xavg)+gama);
            DelX = 2*rand(1,dim).*(abs(Stp)); 
            %% AVOA过程
            %参数初始化
            lBest2 = RndX(current_nP, i);%从支配域中挑选一个除i以外的个体作为第二好的位置
            a=unifrnd(-2,2,1,1)*((sin((pi/2)*(it/MaxIt))^gamma)+cos((pi/2)*(it/MaxIt))-1);% 式子.(3)
            P1=(2*rand+1)*(1-(it/MaxIt))+a;% 部分式子.(4)
            Xnew = domain(i,:);  % 从种群中获取当前个体位置
            F1=P1*(2*rand()-1);% 式子.(4)       
            random_vulture_X=random_select(lBest,lBest2,alpha,betha);% 式子.(1)  
            %计算新个体
            if abs(F1) >= 1 % Exploration:(探测阶段)
                Xnew = exploration(Xnew, random_vulture_X, F1, p1, ub, lb);% 式子.(5)
            elseif abs(F1) < 1 % Exploitation:(开发阶段)
                Xnew = exploitation(Xnew, lBest, lBest2, random_vulture_X, F1, p2, p3, dim);% 式子.(9)
            end    
            % 检查越界
            FU=Xnew>ub;FL=Xnew<lb;
            Xnew=(Xnew.*(~(FU+FL)))+ub.*FU+lb.*FL;
            pNew = SOLUTION(Xnew);
            CostNew=pNew.obj;            
            % 将Xnew放入整体种群
            % 支配计算
            sub_f = CostNew - domain_Cost(i, :); 
            sub_f_neg = size(find(sub_f < 0), 2); %差值中负数的个数
            if sub_f_neg~=0
                % Xnew不被Xi支配，放进整体解，但是不更改Xi，若更差就不要了
                totalPop = [totalPop, pNew];
            end
            % 解集质量提高机制(可运用于所有算法）
            if rand < 0.5
                EXP=exp(-5*rand*it/MaxIt);
                r = floor(Unifrnd(-1,2,1,1));
    
                u=2*rand(1,dim); 
                w=Unifrnd(0,2,1,dim).*EXP;               %(Eq.19-1)
                
                % 随机三个个体
                [A, B, C] = RndX2(current_nP, i);
                Xr = [domain(A, :); domain(B, :); domain(C, :)];
                Xavg=(Xr(1,:)+Xr(2,:)+Xr(3,:))/3;           %(Eq.19-2)         
                % 计算Xnew1
                beta=rand(1,dim);
                Xnew1 = beta.*(Best_X)+(1-beta).*(Xavg); %(Eq.19-3)
                Xnew2 = zeros(1, dim);
                % 对每个维度进行更新
                for j=1:dim
                    if w(j)<1 
                        Xnew2(j) = Xnew1(j)+r*w(j)*abs((Xnew1(j)-Xavg(j))+randn);
                    else
                        Xnew2(j) = (Xnew1(j)-Xavg(j))+r*w(j)*abs((u(j).*Xnew1(j)-Xavg(j))+randn);
                    end
                end
                % 对Xnew2进行限制
                FU=Xnew2>ub;FL=Xnew2<lb;Xnew2=(Xnew2.*(~(FU+FL)))+ub.*FU+lb.*FL;
                pNew2 = SOLUTION(Xnew2);
                CostNew2=pNew2.obj;
                % 将Xnew2放入整体种群
                % 支配计算
                sub_f = CostNew2 - domain_Cost(i, :); 
                sub_f_neg = size(find(sub_f < 0), 2); %差值中负数的个数
                if sub_f_neg~=0
                    % Xnew2不被Xi支配
                    totalPop = [totalPop, pNew2];
                end
                % 一定概率进行Xnew3的计算
                if rand<w(randi(dim)) 
                    % 计算Xnew3
                    SM = RungeKutta(domain(i,:),Xnew2,DelX);
                    Xnew3 = exploitation(Xnew2, lBest, lBest2, random_vulture_X, F1, p2, p3, dim);  % (Eq. 20)
                    % 对Xnew3进行限制
                    FU=Xnew3>ub;FL=Xnew3<lb;
                    Xnew3=(Xnew3.*(~(FU+FL)))+ub.*FU+lb.*FL;
                    pNew3 = SOLUTION(Xnew3);
                    CostNew3=pNew3.obj;
                    % 将Xnew3放入整体种群
                    % 支配计算
                    sub_f = CostNew3 - domain_Cost(i, :); 
                    sub_f_neg = size(find(sub_f < 0), 2); %差值中负数的个数
                    if sub_f_neg~=0
                        % Xnew3不被Xi支配
                        totalPop = [totalPop, pNew3];
                    end
                end
            end
%             % 更新最优个体
%             sub_f = domain_Cost(i, :) - Best_Cost; 
%             sub_f_pos = size(find(sub_f > 0), 2); %差值中正数的个数
%             if sub_f_pos == 0 % 若Xi与XBest相等或者Xi支配XBest       
%                 Best_X(1, :) = domain(i, :);
%                 Best_Cost(1, :) = domain_Cost(i, :);
%             end
        end
    end
    %% 排除掉相同个体
    % 排除参数相同
    X = totalPop.decs;
    [~, uniIndex] = unique(X, "rows");%把重复的排除掉
    totalPop = totalPop(uniIndex);
    %更新种群
    newPop = eliminate(totalPop, nP);%筛选一部分为新个体（包含网格法，每个网格选一个）
end
function [random_vulture_X]=random_select(Best_vulture1_X,Best_vulture2_X,alpha,betha)
    probabilities=[alpha, betha ];
    if (rouletteWheelSelection( probabilities ) == 1)
            random_vulture_X=Best_vulture1_X;
    else
            random_vulture_X=Best_vulture2_X;
    end
end


function [index] = rouletteWheelSelection(x)
    index=find(rand() <= cumsum(x) ,1,'first');
    % cumsum 返回累计和向量
    % rand() <= cumsum(x):每一维的累计和是否大于等于随机数(0,1)？1:0
    % k = find(X,n,direction) direction 的默认值为 'first'时，即查找与非零元素对应的前 n 个索引。
    % find(X,1,'first')返回第一个非零元素的下标(按列优先)
end


function [current_vulture_X] = exploration(current_vulture_X, random_vulture_X, F, p1, ub, lb)
    if rand<p1
        current_vulture_X=random_vulture_X-(abs((2*rand)*random_vulture_X-current_vulture_X))*F;% 式子.(6),(7)
    else
        current_vulture_X=(random_vulture_X-(F)+rand()*((ub-lb)*rand+lb));% 式子.(8)
    end
    if rand()>0.5
        Dim = size(current_vulture_X,2);
        opp_X = ub + lb - current_vulture_X;
        k = 2;
        opposite_X = repmat(opp_X,k,1);
        for s = 1:k
            degree = round(rand * (Dim - 1));
            for i = 1:degree
                L = round(rand * Dim);
                if L == 0
                    L = 1;
                end
                opposite_X(k,L) = current_vulture_X(L);
            end
        end
        opposite_X = mean(opposite_X);%POBL
        % 检查越界
        FU=opposite_X>ub;FL=opposite_X<lb;
        opposite_X=(opposite_X.*(~(FU+FL)))+ub.*FU+lb.*FL;
        X1 = SOLUTION(opposite_X);
        X2 = SOLUTION(current_vulture_X);
        % 支配计算
        sub_f = X1.objs - X2.objs;
        sub_f_neg = size(find(sub_f < 0), 2); %差值中负数的个数
        if sub_f_neg~=0
            % opposite_X不被current_vulture_X支配，更改current_vulture_X，若更差就不要了
            current_vulture_X = opposite_X;
        end
    end
end


function [current_vulture_X] = exploitation(current_vulture_X, Best_vulture1_X, Best_vulture2_X, ...
                                                                      random_vulture_X, F, p2, p3, dim)
% phase 1
    if  abs(F)<0.5
        if rand<p2
            A=Best_vulture1_X-((Best_vulture1_X.*current_vulture_X)./(Best_vulture1_X-current_vulture_X.^2))*F;% 部分式子.(15)
            B=Best_vulture2_X-((Best_vulture2_X.*current_vulture_X)./(Best_vulture2_X-current_vulture_X.^2))*F;% 部分式子.(15)
            current_vulture_X=(A+B)/2;% 式子.(16)
        else
            current_vulture_X=random_vulture_X-abs(random_vulture_X-current_vulture_X)*F.*levyFlight(dim);% 式子.(17)
        end
    end
    % phase 2
    if  abs(F)>=0.5
        if rand<p3
            current_vulture_X=(abs((2*rand)*random_vulture_X-current_vulture_X))*(F+rand)-(random_vulture_X-current_vulture_X);%式子.(10),(11)
        else
            s1=random_vulture_X.* (rand()*current_vulture_X/(2*pi)).*cos(current_vulture_X);% 部分式子.(12)
            s2=random_vulture_X.* (rand()*current_vulture_X/(2*pi)).*sin(current_vulture_X);% 部分式子.(12)
            current_vulture_X=random_vulture_X-(s1+s2);% 式子.(13)
        end
    end
end


function [ o ]=levyFlight(dim)% Levy飞行函数
    beta=3/2;
    sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
    u=randn(1,dim)*sigma;
    v=randn(1,dim);
    step=u./abs(v).^(1/beta);% .^ 按元素求幂
    o=step;
end
% 挑选三个随即个体的函数
function [A]=RndX(nP,i)
Qi=randperm(nP);
Qi(Qi==i)=[];
A=Qi(1);
end
function z=Unifrnd(a,b,c,dim)
a2 = a/2;
b2 = b/2;
mu = a2+b2;
sig = b2-a2;
z = mu + sig .* (2*rand(c,dim)-1);
end

% 挑选三个随即个体的函数
function [A, B, C]=RndX2(nP,i)
Qi=randperm(nP);
Qi(Qi==i)=[];
A=Qi(1);B=Qi(2);C=Qi(3);
end











